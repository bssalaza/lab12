package lab12;

public class EncryptionTester {
	
	public static void main(String[] args) throws Exception {
        String encryptedFilePath = "src/lab12/encrypted.txt";
        String decryptedFilePath = "src/lab12/decrypted.txt";
        String inputFilePath = "src/lab12/encryptMe.txt";
        String outputFilePath = "src/lab12/newEncrypted.txt";
		
        int shift = 4; // Says how much you would like to shift

        Encrypter enc = new Encrypter(shift);

		enc.encrypt(inputFilePath, outputFilePath);
		enc.decrypt(encryptedFilePath, decryptedFilePath);

	}


}
